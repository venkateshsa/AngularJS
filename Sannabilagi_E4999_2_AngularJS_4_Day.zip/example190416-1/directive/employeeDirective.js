demoapp.directive('employeeDirective', function(){
	return{
		restrict: 'AE',
		templateUrl: 'directive/employeeDirective.html'
	};
});