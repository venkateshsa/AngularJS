demoapp.factory('employeeFactory', function(){
	employeesList = [
		{
			name:'John',
			role:'Developer',
			project:{
				pname:'JCP',
				location:'Mannesota'
			}
		},
		{
			name:'Miller',
			role:'Project Manager',
			project:{
				pname:'JPMC',
				location:'NewYork'
			}
		},
		{
			name:'Don',
			role:'Technical Architech',
			project:{
				pname:'Panasonic',
				location:'Texas'
			}
		},
		{
			name:'Heric',
			role:'Team Lead',
			project:{
				pname:'Target',
				location:'Boston'
			}
		}
	];
	
	return{
		sharedProfile : {
			name: " ",
			role: " ",
			project: {
				pname:'',
				location:''
			}
		},
		shareProfile : function(newEmployee){
			this.sharedProfile.name = newEmployee.name;
			this.sharedProfile.role = newEmployee.role;
			this.sharedProfile.project.pname = newEmployee.project.pname;
			this.sharedProfile.project.location = newEmployee.project.location;
		},
		getEmplayeeList : employeesList,
		addEmpProfile : function(newEmployee){			
			this.sharedProfile.name = newEmployee.name;
			this.sharedProfile.role = newEmployee.role;
			this.sharedProfile.project.pname = newEmployee.project.pname;
			this.sharedProfile.project.location = newEmployee.project.location;
			
			employeesList.push(this.sharedProfile);
		},		
		updateshareProfile : function(newEmployee,ind){
			employeesList[ind].name = newEmployee.name;
			employeesList[ind].role = newEmployee.role;
			employeesList[ind].project.pname = newEmployee.project.pname;
			employeesList[ind].project.location = newEmployee.project.location;			
		}
	}
});