demoapp.controller('EmployeeController', function($rootScope, $scope, employeeFactory){
	
	$scope.employees = [];
	
	$rootScope.activeActions = [];
	
	//add employee
	$scope.addEmp = function(){
		var newEmp = {
			name:$scope.name,
			role:$scope.role,
			project:{
				pname:$scope.pname,
				location:$scope.location
			}
		};
				
		$scope.name = '';
		$scope.role = '';
		$scope.pname = '';
		$scope.location = '';
		
		employeeFactory.addEmpProfile(newEmp);			
		$rootScope.activeActions.push({mess:'New employee record is added.'});
	};
	
	//delete employee
	$scope.deleteEmp = function(e){
		$scope.employees.splice(e,1);
		$rootScope.activeActions.push({mess:'Record is deleted.'});
	};
	
	$scope.seeProfile = function(currentEmployee, ind){
		employeeFactory.shareProfile(currentEmployee);
		$rootScope.currentIndex = ind;
		$rootScope.empname = currentEmployee.name;
		$scope.name = currentEmployee.name;
		$scope.role = currentEmployee.role;
		$scope.pname = currentEmployee.project.pname;
		$scope.location = currentEmployee.project.location;		
		$rootScope.activeActions.push({mess: currentEmployee.name+' is record is viewed.'});	
	};
		
	$scope.init = function(){
		$scope.employees = employeeFactory.getEmplayeeList;
		employeeFactory.shareProfile($scope.employees[0]);
		$rootScope.currentIndex = 0;
		$rootScope.empname = $scope.employees[0].name;		
	};
	$scope.init();
});