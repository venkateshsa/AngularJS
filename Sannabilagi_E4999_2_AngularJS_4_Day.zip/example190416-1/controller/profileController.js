profile.controller('ProfileController', function($rootScope, $scope, employeeFactory){
	$scope.currentEmployee = employeeFactory.sharedProfile;	
	
	$scope.updateEmp = function(currentEmployee){		
		employeeFactory.updateshareProfile(currentEmployee, $rootScope.currentIndex);
	}
});