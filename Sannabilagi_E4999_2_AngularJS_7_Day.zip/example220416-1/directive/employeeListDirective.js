demoapp.directive('employeeListDirective', function(){
	return{
		restrict: 'AE',		
		templateUrl: 'directive/employeeListDirective.html'
	};
});