demoapp.directive('myTextDirective', ['$interval', function($interval) {

	function link(scope, element, attrs) {
	   
		scope.$watch(attrs.myTextDirective, function(value) {
			$interval(function(){				
				scope.showme = false;
			},3000);
		});
	  
	}

	return {
		link: link
	};
}]);