demoapp.directive('employeeDirective', function(){
	return{
		restrict: 'AE',
		scope: {
            /* make typeattribute="whatever" bind two-ways (=)
            $scope.whatever from the parent to $scope.controltype
            on this directive's scope */ 
			// = => DataType  2. Bindings
            controltype: '=typeattribute',
            /* reference a function from the parent through
               funcattribute="somefunc()" and stick it our
               directive's scope in $scope.controlfunc */ 
			// & => Method name 3. Expressions
            controlfunc: '&funcattribute',
            /* pass a string value into the directive */ 
			// @ => Attribute 1. Attribute
            controlval: '@valattribute'		
        },
		templateUrl: 'directive/employeeDirective.html'	
	};
});