demoapp.factory('employeeFactory', function(){
	employeesList = [
		{
			name:'Venkatesh',
			role:'Sr. Software Engg',
			project:{
				pname:'GoodSam',
				location:'Bangalore'
			}
		},
		{
			name:'Pradeepa',
			role:'Project Manager',
			project:{
				pname:'GoodSam',
				location:'Chanai'
			}
		},
		{
			name:'Karthika',
			role:'Technical Lead',
			project:{
				pname:'GoodSam',
				location:'Bangalore'
			}
		}	
	];
	
	return{
		sharedProfile : {
			name: " ",
			role: " ",
			project: {
				pname:'',
				location:''
			}
		},
		shareProfile : function(newEmployee){
			this.sharedProfile.name = newEmployee.name;
			this.sharedProfile.role = newEmployee.role;
			this.sharedProfile.project.pname = newEmployee.project.pname;
			this.sharedProfile.project.location = newEmployee.project.location;
		},
		getEmplayeeList : employeesList,
		addEmpProfile : function(newEmployee){			
			this.sharedProfile.name = newEmployee.name;
			this.sharedProfile.role = newEmployee.role;
			this.sharedProfile.project.pname = newEmployee.project.pname;
			this.sharedProfile.project.location = newEmployee.project.location;
			
			employeesList.push(newEmployee);
		},		
		updateshareProfile : function(newEmployee,ind){
			employeesList[ind].name = newEmployee.name;
			employeesList[ind].role = newEmployee.role;
			employeesList[ind].project.pname = newEmployee.project.pname;
			employeesList[ind].project.location = newEmployee.project.location;			
		}
	}
});