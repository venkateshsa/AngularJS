demoapp.controller('EmployeeController', function($rootScope, $scope, employeeFactory){
	
	$scope.employees = [];
	
	$rootScope.activeActions = [];
	$scope.currentEmployee = {};
	
	$scope.showme = false;
			
	//add employee
	$scope.addEmp = function(){	

		var newEmp = {
			name:$scope.currentEmployee.name,
			role:$scope.currentEmployee.role,
			project:{
				pname:$scope.currentEmployee.project.pname,
				location:$scope.currentEmployee.project.location
			}
		};
				
		$scope.currentEmployee.name = '';
		$scope.currentEmployee.role = '';
		$scope.currentEmployee.project.pname = '';
		$scope.currentEmployee.project.location = '';
		
		employeeFactory.addEmpProfile(newEmp);				
		$rootScope.activeActions.push({mess:'New employee record is added.'});
		$scope.showme = true;		
	};
	
	//delete employee
	$scope.deleteEmp = function(e){
		$scope.employees.splice(e,1);
		$rootScope.activeActions.push({mess:'Record is deleted.'});
	};
	
	$scope.seeProfile = function(currentEmployee, ind){
		employeeFactory.shareProfile(currentEmployee);
		$rootScope.currentIndex = ind;		
		$rootScope.activeActions.push({mess: currentEmployee.name+'\'s record is viewed.'});	
	};
		
	$scope.init = function(){
		$scope.employees = employeeFactory.getEmplayeeList;
		employeeFactory.shareProfile($scope.employees[0]);			
		$rootScope.currentIndex = 0;
		$rootScope.empname = 'E4999 Venkatesh C S';		
	};
	$scope.init();
});