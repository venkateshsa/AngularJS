profile.controller('ProfileController', function($rootScope, $scope, employeeFactory){
	$scope.selectedEmployee = employeeFactory.sharedProfile;	
	
	$scope.updateEmp = function(){		
		employeeFactory.updateshareProfile($scope.selectedEmployee, $rootScope.currentIndex);
		$rootScope.activeActions.push({mess:'Employee record is updated.'});
	}
});