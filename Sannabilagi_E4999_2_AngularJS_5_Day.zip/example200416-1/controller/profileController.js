profile.controller('ProfileController', function($rootScope, $scope, employeeFactory){
	$scope.currentEmployee = employeeFactory.sharedProfile;	
	
	$scope.updateEmp = function(){		
		employeeFactory.updateshareProfile($rootScope.selectedEmployee, $rootScope.currentIndex);
	}
});