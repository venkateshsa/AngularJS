demoapp.controller('EmployeeController', function($rootScope, $scope, employeeFactory){
	
	$scope.employees = [];
	
	$rootScope.activeActions = [];
	$scope.currentEmployee = {};
	$rootScope.selectedEmployee = {
			name:'',
			role:'',
			project:{
				pname:'',
				location:''
			}
	};
		
	//add employee
	$scope.addEmp = function(){	

		var newEmp = {
			name:$scope.currentEmployee.name,
			role:$scope.currentEmployee.role,
			project:{
				pname:$scope.currentEmployee.project.pname,
				location:$scope.currentEmployee.project.location
			}
		};
				
		$scope.currentEmployee.name = '';
		$scope.currentEmployee.role = '';
		$scope.currentEmployee.project.pname = '';
		$scope.currentEmployee.project.location = '';
		
		employeeFactory.addEmpProfile(newEmp);	
		$scope.employees = employeeFactory.getEmplayeeList;	
		$rootScope.activeActions.push({mess:'New employee record is added.'});
	};
	
	//delete employee
	$scope.deleteEmp = function(e){
		$scope.employees.splice(e,1);
		$rootScope.activeActions.push({mess:'Record is deleted.'});
	};
	
	$scope.seeProfile = function(currentEmployee, ind){
		employeeFactory.shareProfile(currentEmployee);
		$rootScope.currentIndex = ind;
		
		$rootScope.selectedEmployee.name = currentEmployee.name;
		$rootScope.selectedEmployee.role = currentEmployee.role;
		$rootScope.selectedEmployee.project.pname = currentEmployee.project.pname;
		$rootScope.selectedEmployee.project.location = currentEmployee.project.location;		
			
		$rootScope.activeActions.push({mess: $rootScope.selectedEmployee.name+' is record is viewed.'});	
	};
		
	$scope.init = function(){
		$scope.employees = employeeFactory.getEmplayeeList;
		employeeFactory.shareProfile($scope.employees[0]);
		
		$rootScope.selectedEmployee.name = $scope.employees[0].name;
		$rootScope.selectedEmployee.role = $scope.employees[0].role;
		$rootScope.selectedEmployee.project.pname = $scope.employees[0].project.pname;
		$rootScope.selectedEmployee.project.location = $scope.employees[0].project.location;
				
		$rootScope.currentIndex = 0;
		$rootScope.empname = 'E4999 Venkatesh C S';		
	};
	$scope.init();
});