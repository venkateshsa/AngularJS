demoapp.factory('employeeFactory', function(){
	return{
		sharedProfile : {
			name: " ",
			role: " ",
			project: " "
		},
		updateSharedProfile : function(newEmployee){
			this.sharedProfile.name = newEmployee.name;
			this.sharedProfile.role = newEmployee.role;
			this.sharedProfile.project = newEmployee.project;
		}
	}
});