demoapp.controller('EmployeeController', function($scope, employeeFactory){
	
	$scope.employees = [
		{
			name:'John',
			role:'Developer',
			project:{
				pname:'JCP',
				loaction:'Mannesota'
			}
		},
		{
			name:'Miller',
			role:'Project Manager',
			project:{
				pname:'JPMC',
				loaction:'NewYork'
			}
		},
		{
			name:'Don',
			role:'Technical Architech',
			project:{
				pname:'Panasonic',
				loaction:'Texas'
			}
		},
		{
			name:'Heric',
			role:'Team Lead',
			project:{
				pname:'Target',
				loaction:'Boston'
			}
		}
	];
	
	//add employee
	$scope.addEmp = function(){
		var newEmp = {
			name:$scope.name,
			role:$scope.role,
			project:{
				pname:$scope.pname,
				loaction:$scope.loaction
			}
		};
		$scope.employees.push(newEmp);
		$scope.name = '';
		$scope.role = '';
		$scope.pname = '';
		$scope.loaction = '';
	};
	
	//delete employee
	$scope.deleteEmp = function(e){
		$scope.employees.splice(e,1);
	};
	
	$scope.seeProfile = function(currentEmployee){
		employeeFactory.updateSharedProfile(currentEmployee);
	};
	
	$scope.init = function(){
		$scope.seeProfile($scope.employees[0]);
	};
	$scope.init();
});