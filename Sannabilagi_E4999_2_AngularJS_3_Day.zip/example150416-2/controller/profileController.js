profile.controller('ProfileController', function($scope, employeeFactory){
	$scope.currentEmployee = employeeFactory.sharedProfile;
	$scope.name = 'fName';
	$scope.role = 'mRole';
	$scope.project = 'mProject';
	
});