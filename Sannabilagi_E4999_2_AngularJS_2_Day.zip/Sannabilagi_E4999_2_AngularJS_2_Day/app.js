var app=angular.module("DemoApp",[]);
app.controller('FirstController', function($scope){
	$scope.employees = [{"name":"John","role":"Admin"},{"name":"Mark","role":"Super Admin"},{"name":"Bill","role":"IT"}];
	
	$scope.addemp=function(){
		$scope.employees.push({name:$scope.name,role:$scope.role});
		$scope.name = null;
		$scope.role = null;
	}
	
	$scope.deleteEmp =function(index){
		$scope.employees.splice(index, 1);
	}
});

app.directive('firstDirective', function(){
	return {
		template: '<h3>{{e.name +" is "+ e.role}} build by directive  <button ng-click="deleteEmp($index)">X</button></h3>'
	}
});